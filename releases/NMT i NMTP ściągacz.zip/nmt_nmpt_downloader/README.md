# NMT i NMTP ściągacz

Wtyczka QGIS pobierająca numeryczny model terenu (NMT) i numeryczny model pokrycia terenu (NMPT) z WCS GUGiK, dla obszaru wokół obiektów warstwy. Działa niezależnie od wtyczki „Pobieracz danych GUGiK”.

## Instalacja

1. QGIS 3.28–3.x: **Wtyczki → Zarządzanie wtyczkami → Zainstaluj z ZIP**.
2. Wybierz `NMT i NMTP ściągacz.zip` i włącz wtyczkę.
3. Otwórz **Wtyczki → NMT i NMTP ściągacz → NMT i NMTP ściągacz** albo kliknij ikonę gór ze strzałką.

Wymagane są biblioteki standardowej instalacji QGIS: PyQGIS, GDAL/OGR, NumPy, lxml i requests. Używaj Pythona dostarczonego z QGIS. Nie instaluj `qgis` przez pip. Sprawdzono QGIS 3.40.6 / Qt5 / Python 3.13 na Linuksie. Windows i macOS nie zostały tutaj sprawdzone. QGIS 4 nie jest deklarowany jako obsługiwany.

## Przykład: trzy działki, promień 20 km

1. Dodaj warstwę działek do projektu i wybierz ją w oknie wtyczki.
2. Jeśli chcesz użyć tylko trzech działek z większej warstwy, zaznacz je w QGIS i włącz **Tylko zaznaczone obiekty**. Bez tej opcji używana jest cała warstwa.
3. Wpisz **20000 m**. To bufor wokół geometrii działek, nie wokół ich centroidów. Nakładające się obszary nie powodują wielokrotnego pobierania tego samego kafla.
4. Zaznacz **NMT** i **NMPT**. Ustaw różne foldery, np. `D:/Modele/NMT` oraz `D:/Modele/NMPT`, i folder raportów `D:/Modele/Raporty`.
5. Wybierz rozmiar piksela. Domyślnie jest to **1 m** dla obu zasobów. Opcja **Źródłowa** odczytuje rozdzielczość z DescribeCoverage (w sprawdzonych usługach: NMT 1 m, NMPT 0,5 m). Opcje 2/5/10 m są przeliczeniem danych na rzadszą siatkę, a nie osobnymi pomiarami o innej dokładności. WCS stosuje domyślną interpolację najbliższego sąsiada.
6. Wybierz układ wysokościowy, domyślnie **PL-EVRF2007-NH**. Nie łącz plików z różnych układów wysokościowych w jeden model.
7. Kliknij **Pobierz**. Zobaczysz etap przygotowania, postęp kafli, aktywne żądania, pobrane MB, szacowane pozostałe MB, średnią prędkość i ETA. Po zakończeniu pojawi się podsumowanie.

Warstwy wynikowe nie są automatycznie dodawane do projektu. Okno można ukryć i ponownie otworzyć ikoną wtyczki; pobieranie działa dalej. **Anuluj** zatrzymuje kolejkę i zachowuje zakończone pliki oraz raport. Aktywne połączenie może czekać do 90 s na dane; limit odczytu nie jest limitem czasu całego pobierania.

## Wyniki i efektywność

- Każdy plik to pełny kafel **GeoTIFF Float32**, skompresowany DEFLATE, w **EPSG:2180**. Kafle na obrzeżach mogą wykraczać poza bufor. Nie powstaje automatycznie jeden połączony raster.
- Domyślnie kafel ma 1024 × 1024 piksele, a jednocześnie pobierane są dwa kafle. Można ustawić 512/1024/2048 pikseli i 1–4 pobrania równoległe. Mniejsze kafle pomagają przy limitach i niestabilności usługi; większe zmniejszają liczbę żądań. Pamięć zależy od wielkości kafla i liczby pobrań, nie od rozmiaru całego rastra.
- Kafle planowane są przy każdej geometrii, z usuwaniem duplikatów. Indeks przestrzenny ogranicza liczbę geometrii sprawdzanych przy walidacji kafla. Nie pobieramy pustego prostokąta między daleko odległymi obiektami.
- HTTP jest pobierane strumieniowo. Tymczasowy ASCII Grid jest po walidacji konwertowany i usuwany. Gotowy GeoTIFF trafia do folderu atomowo, dopiero po kontroli odczytu, wymiarów i georeferencji. Weryfikacja TLS pozostaje włączona.
- Ponowne uruchomienie z tymi samymi parametrami pomija poprawne pliki. Sygnatura obejmuje usługę, zasób, układ, rozdzielczość i siatkę. Zmiana bufora może ponownie wykorzystać te same pełne kafle. Przy aktualizacji danych w GUGiK wyłącz opcję pomijania plików. Wznawianie dotyczy całych kafli; niedokończony kafel pobierany jest od początku.
- Pliki o niezgodnej sygnaturze lub nieczytelne są zachowywane, a konflikt trafia do raportu. Przenieś taki plik, aby umożliwić pobranie kafla. Blokada folderu chroni przed równoczesnym zapisem przez dwa zadania/instancje QGIS. Po awarii usuń `.nmt_nmpt_downloader.lock` dopiero po sprawdzeniu, że żadne pobieranie już nie trwa.
- Duże obszary w 1 m oznaczają miliardy pikseli. Okrąg o promieniu 20 km to około **1,26 mld pikseli na zasób**: około 5 GB nieskompresowanych wartości Float32, przed doliczeniem kafli brzegowych. Transfer ASCII może być wielokrotnie większy, a kompresja GeoTIFF redukuje rozmiar na dysku. Wybór 2 m zmniejsza liczbę pikseli czterokrotnie. ETA i pozostałe MB są przybliżeniem na podstawie ukończonych kafli; nie obejmują dokładnie opóźnień usługi ani przyszłych ponowień.
- MB oznacza 1 000 000 bajtów. Licznik sieciowy obejmuje także ponowione transfery. Wcześniej pobrane pliki nie są doliczane do nowych transferów.

## Raporty i braki

Każde uruchomienie tworzy oddzielny folder `raport_DATA_ID`:

- `report.md`: czytelne podsumowanie, wyniki per zasób i lista braków/błędów.
- `report.json`: parametry, źródła i ich rozdzielczości, każdy kafel, adres żądania, liczba prób, bajty i przyczyna problemu. Zasięgi kafli zapisane są jako `[xmin, ymin, xmax, ymax]` w EPSG:2180. Czasy ISO są w UTC.
- `events.jsonl`: bieżący dziennik zdarzeń; raport zbiorczy aktualizowany jest okresowo i na końcu.
- `obszar.geojson`: bufory wejściowych obiektów w EPSG:4326.
- `obszary_problemowe.geojson`: żądane fragmenty kafli, w których wystąpiły braki, błędy lub anulowanie. Dla częściowych braków to zasięg diagnostyczny, a nie dokładny kształt dziur.
- `masks/*_braki.tif`: dokładne maski braków NoData w żądanym obszarze, EPSG:2180; **1 = brak**, 0 = poza brakami. Liczone są piksele ze środkiem wewnątrz bufora. Dla obszaru mniejszego od piksela raport wskazuje brak środka piksela.

`downloaded` = pobrano, `reused` = użyto poprawnego istniejącego pliku, `partial` = zapisano raster z częściowymi brakami, `missing` = wyłącznie NoData, `failed` = błąd pobrania/walidacji, `canceled` = anulowano, `outside_pixels` = obszar mniejszy od siatki pikseli. Przy `partial` pole `reused` rozróżnia pobranie i użycie istniejącego pliku.

NoData nie przerywa innych pobrań. Awaria sieci/usługi nie jest uznawana za dowiedziony brak danych. Powód z HTTP/WCS trafia do raportu, a żądania przejściowo błędne są ponawiane maksymalnie trzy razy (HTTP 4xx poza 408/429 nie jest ponawiane). Nieprawidłowe geometrie wejściowe są naprawiane, a nierozwiązywalne problemy raportowane z ID obiektu; pozostałe obiekty są przetwarzane.

## Źródła i format danych

Używane usługi:

- NMT: `https://mapy.geoportal.gov.pl/wss/service/PZGIK/NMT/GRID1/WCS/DigitalTerrainModel`
- NMPT: `https://mapy.geoportal.gov.pl/wss/service/PZGIK/NMPT/GRID1/WCS/DigitalSurfaceModel`

Każde zadanie sprawdza DescribeCoverage. Używamy WCS 1.0.0 `GetCoverage`, EPSG:2180 i zasobów `DTM_PL-EVRF2007-NH` / `DSM_PL-EVRF2007-NH`, ewentualnie odpowiedników KRON86. Nazwa `Orthoimagery` nie pasuje do tych usług.

Wtyczka celowo pobiera numeryczny `image/x-aaigrid`, a nie wizualizację. W rzeczywistej próbie WCS 2.0.1 `image/tiff` z usługi NMT zwrócił raster Byte z zaokrąglonymi wysokościami; konwersja numerycznego ASCII do Float32 zachowuje ułamkowe wartości wysokości. To pobieranie modelu udostępnionego przez WCS, bez wyboru roku lub archiwalnego arkusza. Nie pobieramy WMS ani zrzutów mapy.

Test rzeczywisty: NMT i NMPT, obszary 64 × 64 m i 512 × 512 m w Warszawie, piksel 1 m, EVRF2007; poprawny odczyt obu GeoTIFF-ów Float32 i raport zakończony bez braków. 12 testów lokalnych obejmuje bufor 20 km i przeliczenie warstwy punktowej z EPSG:4326, deduplikację, NoData, HTTP 503/404, ponowienia, kontynuowanie pozostałych kafli, cache, anulowanie, zachowanie obcych plików i konstrukcję okna QGIS. Całego obszaru o promieniu 20 km nie pobierano w ramach weryfikacji.

Kod źródłowy: `core.py` — geometrie i rastry; `engine.py` — transfery i raporty; `plugin.py` — interfejs i QgsTask. Testy w repozytorium: `tests_nmt_nmpt/test_downloader.py`. Licencja: GPL-3.0, plik `LICENSE`.
